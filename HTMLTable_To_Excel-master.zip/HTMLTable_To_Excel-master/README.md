# HTMLTable_To_Excel
JavaScript library to convert HTMLTable to Excel with cross browser functionlity
How To USe:
1. Import saveAsExcel.js into HTML web page using <script>
2. call saveAsExcel() method on required event by passing two attributes, id of table to be saved as Excel and file name for the downloaded file
3. E.g., saveAsExcel('tableToExcel', 'Jaffa.xls')
4. For complete Usage view demo.html
